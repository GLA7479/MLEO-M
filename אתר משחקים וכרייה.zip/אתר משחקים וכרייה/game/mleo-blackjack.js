// ============================================================================
// MLEO 21 Challenge - Full Professional 21 Challenge
// Complete with Double Down, Split, Insurance, Surrender
// ============================================================================

import { useEffect, useRef, useState } from "react";
import { useRouter } from "next/router";
import Layout from "../components/Layout";
import { useConnectModal, useAccountModal } from "@rainbow-me/rainbowkit";
import { useAccount, useDisconnect, useSwitchChain, useWriteContract, usePublicClient, useChainId } from "wagmi";
import { parseUnits } from "viem";
import { getFreePlayStatus } from "../lib/free-play-system";
import {
  finishArcadeSession,
  startFreeplayArcadeSession,
  startPaidArcadeSession,
} from "../lib/arcadeSessionClient";
import { createDeterministicCardDeck } from "../lib/arcadeDeterministicCards";
import {
  debitSharedVault,
  initSharedVault,
  peekSharedVault,
  readSharedVault,
  subscribeSharedVault,
} from "../lib/sharedVault";

function useIOSViewportFix() {
  useEffect(() => {
    const root = document.documentElement;
    const vv = window.visualViewport;
    const setVH = () => {
      const h = vv ? vv.height : window.innerHeight;
      root.style.setProperty("--app-100vh", `${Math.round(h)}px`);
    };
    const onOrient = () => requestAnimationFrame(() => setTimeout(setVH, 250));
    setVH();
    if (vv) {
      vv.addEventListener("resize", setVH);
      vv.addEventListener("scroll", setVH);
    }
    window.addEventListener("orientationchange", onOrient);
    return () => {
      if (vv) {
        vv.removeEventListener("resize", setVH);
        vv.removeEventListener("scroll", setVH);
      }
      window.removeEventListener("orientationchange", onOrient);
    };
  }, []);
}

const LS_KEY = "mleo_blackjack_v3";
const MIN_PLAY = 100;
const SUITS = ["♠️", "♥️", "♦️", "♣️"];
const VALUES = ["A", "2", "3", "4", "5", "6", "7", "8", "9", "10", "J", "Q", "K"];
const CLAIM_CHAIN_ID = Number(process.env.NEXT_PUBLIC_CLAIM_CHAIN_ID || 97);
const CLAIM_ADDRESS = (process.env.NEXT_PUBLIC_MLEO_CLAIM_ADDRESS || "").trim();
const MLEO_DECIMALS = Number(process.env.NEXT_PUBLIC_MLEO_DECIMALS || 18);
const GAME_ID = 2;
const MINING_CLAIM_ABI = [{ type: "function", name: "claim", stateMutability: "nonpayable", inputs: [{ name: "gameId", type: "uint256" }, { name: "amount", type: "uint256" }], outputs: [] }];
const S_CLICK = "/sounds/click.mp3";
const S_WIN = "/sounds/gift.mp3";
const RESERVED_STAKE_MULTIPLIER = 2.5;

function safeRead(key, fallback = {}) { if (typeof window === "undefined") return fallback; try { const raw = localStorage.getItem(key); return raw ? JSON.parse(raw) : fallback; } catch { return fallback; } }
function safeWrite(key, val) { if (typeof window === "undefined") return; try { localStorage.setItem(key, JSON.stringify(val)); } catch {} }
function fmt(n) { if (n >= 1e9) return (n / 1e9).toFixed(2) + "B"; if (n >= 1e6) return (n / 1e6).toFixed(2) + "M"; if (n >= 1e3) return (n / 1e3).toFixed(2) + "K"; return Math.floor(n).toString(); }
function formatPlayDisplay(n) { const num = Number(n) || 0; if (num >= 1e6) return (num / 1e6).toFixed(num % 1e6 === 0 ? 0 : 2) + "M"; if (num >= 1e3) return (num / 1e3).toFixed(num % 1e3 === 0 ? 0 : 2) + "K"; return num.toString(); }
function shortAddr(addr) { if (!addr || addr.length < 10) return addr || ""; return `${addr.slice(0, 6)}...${addr.slice(-4)}`; }
function normalizeWholeAmount(value) { return Math.max(0, Math.floor(Number(value) || 0)); }

function createDeck() {
  const deck = [];
  for (const suit of SUITS) {
    for (const value of VALUES) {
      deck.push({ suit, value, display: `${value}${suit}` });
    }
  }
  return deck;
}

function shuffleDeck(deck) {
  const shuffled = [...deck];
  for (let i = shuffled.length - 1; i > 0; i--) {
    const j = Math.floor(Math.random() * (i + 1));
    [shuffled[i], shuffled[j]] = [shuffled[j], shuffled[i]];
  }
  return shuffled;
}

function getCardValue(card) {
  if (!card || !card.value) return 0;
  if (card.value === "A") return 11;
  if (["J", "Q", "K"].includes(card.value)) return 10;
  return parseInt(card.value) || 0;
}

function calculateHandValue(hand) {
  if (!hand || !Array.isArray(hand) || hand.length === 0) return 0;
  let value = 0;
  let aces = 0;
  for (const card of hand) {
    if (!card) continue;
    const cardValue = getCardValue(card);
    if (card.value === "A") aces++;
    value += cardValue;
  }
  while (value > 21 && aces > 0) {
    value -= 10;
    aces--;
  }
  return value;
}

function canSplitCards(hand) {
  if (hand.length !== 2) return false;
  const val1 = getCardValue(hand[0]);
  const val2 = getCardValue(hand[1]);
  return val1 === val2;
}

function PlayingCard({ card, hidden = false, delay = 0 }) {
  if (hidden) {
    return (
      <div 
        className="w-14 h-20 rounded bg-gradient-to-br from-blue-600 to-blue-800 border border-white/30 flex items-center justify-center shadow"
        style={{
          animation: `slideInCard 0.4s ease-out ${delay}ms both`,
          opacity: 0
        }}
      >
        <span className="text-2xl">🂠</span>
      </div>
    );
  }
  
  const isRed = card.suit === "♥️" || card.suit === "♦️";
  const color = isRed ? "text-red-600" : "text-black";
  
  return (
    <div 
      className="w-14 h-20 rounded bg-white border border-gray-400 shadow p-1 relative"
      style={{
        animation: `slideInCard 0.4s ease-out ${delay}ms both`,
        opacity: 0
      }}
    >
      <div className={`text-xl font-bold ${color} absolute top-1 left-2 leading-tight`}>
        {card.value}
      </div>
      <div className={`text-2xl ${color} flex items-center justify-center h-full`}>
        {card.suit}
      </div>
    </div>
  );
}

export default function BlackjackPage() {
  useIOSViewportFix();
  const router = useRouter();
  const wrapRef = useRef(null);
  const headerRef = useRef(null);
  const metersRef = useRef(null);
  const betRef = useRef(null);
  const ctaRef = useRef(null);
  const { openConnectModal } = useConnectModal();
  const { openAccountModal } = useAccountModal();
  const { address, isConnected } = useAccount();
  const { disconnect } = useDisconnect();
  const { switchChain } = useSwitchChain();
  const { writeContractAsync } = useWriteContract();
  const publicClient = usePublicClient();
  const chainId = useChainId();

  const [mounted, setMounted] = useState(false);
  const [vault, setVaultState] = useState(0);
  const [playAmount, setPlayAmount] = useState("100");
  const [isEditingPlay, setIsEditingPlay] = useState(false);
  const [deck, setDeck] = useState([]);
  const [playerHand, setPlayerHand] = useState([]);
  const [opponentHand, setOpponentHand] = useState([]);
  const [gameState, setGameState] = useState("lobby");
  const [gameResult, setGameResult] = useState(null);
  const [isFreePlay, setIsFreePlay] = useState(false);
  const [freePlayTokens, setFreePlayTokens] = useState(0);
  const [showResultPopup, setShowResultPopup] = useState(false);
  const [isFullscreen, setIsFullscreen] = useState(false);
  const [copiedAddr, setCopiedAddr] = useState(false);
  const [claiming, setClaiming] = useState(false);
  const [collectAmount, setCollectAmount] = useState(100);
  const [sessionId, setSessionId] = useState(null);
  const [sessionError, setSessionError] = useState("");
  const [menuOpen, setMenuOpen] = useState(false);
  const [showHowToPlay, setShowHowToPlay] = useState(false);
  const [showStats, setShowStats] = useState(false);
  const [showVaultModal, setShowVaultModal] = useState(false);
  const [sfxMuted, setSfxMuted] = useState(false);
  const clickSound = useRef(null);
  const winSound = useRef(null);

  // Professional 21 Challenge Features
  const [canDouble, setCanDouble] = useState(false);
  const [canSplit, setCanSplit] = useState(false);
  const [canSurrender, setCanSurrender] = useState(false);
  const [showInsurance, setShowInsurance] = useState(false);
  const [insuranceBet, setInsuranceBet] = useState(0);
  const [hasDoubled, setHasDoubled] = useState(false);
  const [hasSurrendered, setHasSurrendered] = useState(false);
  const [splitHands, setSplitHands] = useState([]);
  const [currentSplitIndex, setCurrentSplitIndex] = useState(0);
  const [isSplitGame, setIsSplitGame] = useState(false);

  const [stats, setStats] = useState(() => safeRead(LS_KEY, { 
    totalHands: 0, wins: 0, losses: 0, pushes: 0, totalPlay: 0, totalWon: 0, 
    biggestWin: 0, blackjacks: 0, doubles: 0, splits: 0, surrenders: 0, 
    insuranceWins: 0, insuranceLosses: 0, lastPlay: MIN_PLAY 
  }));
  const sessionIdRef = useRef(null);
  const baseStakeRef = useRef(0);
  const insuranceTakenRef = useRef(false);
  const actionsRef = useRef([]);
  const splitHandOneActionsRef = useRef([]);
  const splitHandTwoActionsRef = useRef([]);

  const playSfx = (sound) => { if (sfxMuted || !sound) return; try { sound.currentTime = 0; sound.play().catch(() => {}); } catch {} };

  const readVaultBalance = () => peekSharedVault().balance;

  const applyVaultDebit = async (amount, gameId) => {
    const result = await debitSharedVault(amount, gameId);
    if (result?.ok) setVaultState(result.balance);
    return result;
  };

  const resetActionLog = (baseStake = 0) => {
    baseStakeRef.current = Math.max(0, Math.floor(Number(baseStake) || 0));
    insuranceTakenRef.current = false;
    actionsRef.current = [];
    splitHandOneActionsRef.current = [];
    splitHandTwoActionsRef.current = [];
  };

  const buildBlackjackPayload = (decision = "play") => ({
    baseStake: baseStakeRef.current,
    insuranceTaken: insuranceTakenRef.current,
    decision,
    actions: actionsRef.current,
    splitHandOneActions: splitHandOneActionsRef.current,
    splitHandTwoActions: splitHandTwoActionsRef.current,
  });

  const finishBlackjackSession = async (decision = "play") => {
    const activeSessionId = sessionIdRef.current;
    if (!activeSessionId) return null;
    const finishResult = await finishArcadeSession(activeSessionId, buildBlackjackPayload(decision));
    if (!finishResult?.success) {
      throw new Error(finishResult?.message || "Failed to finish session");
    }

    const payload = finishResult.serverPayload || {};
    const payout = Math.max(0, Number(payload.payout || 0));
    const profit = Number(payload.profit ?? 0);
    const splitResult = Boolean(payload.split);
    const push = Boolean(payload.push);
    const win = Boolean(payload.won);
    const totalPlay = Math.max(0, Number(payload.usedTotal || baseStakeRef.current));

    if (Array.isArray(payload.dealerCards) && payload.dealerCards.length > 0) {
      setOpponentHand(payload.dealerCards);
    }
    if (splitResult) {
      if (Array.isArray(payload.splitHandOne)) {
        setSplitHands([
          { cards: payload.splitHandOne, play: baseStakeRef.current, finished: true, result: null },
          { cards: Array.isArray(payload.splitHandTwo) ? payload.splitHandTwo : [], play: baseStakeRef.current, finished: true, result: null },
        ]);
      }
    } else if (Array.isArray(payload.playerCards) && payload.playerCards.length > 0) {
      setPlayerHand(payload.playerCards);
    }

    setVaultState(Number(finishResult.balanceAfter || 0));
    if (win && payout > 0) {
      playSfx(winSound.current);
    }

    setGameResult({
      win,
      push,
      playerValue: Number(payload.playerValue || 0),
      opponentValue: Number(payload.dealerValue || 0),
      prize: payout,
      profit,
      blackjack: Boolean(payload.blackjack),
      surrender: Boolean(payload.surrender),
      split: splitResult,
      splitWins: Number(payload.splitWins || 0),
      splitLosses: Number(payload.splitLosses || 0),
      splitPushes: Number(payload.splitPushes || 0),
      insurance: insuranceTakenRef.current && !win && !push && payout > 0,
    });

    setStats((prev) => ({
      ...prev,
      totalHands: prev.totalHands + (splitResult ? 2 : 1),
      wins: prev.wins + (splitResult ? Number(payload.splitWins || 0) : (win ? 1 : 0)),
      losses: prev.losses + (splitResult ? Number(payload.splitLosses || 0) : (!win && !push ? 1 : 0)),
      pushes: prev.pushes + (splitResult ? Number(payload.splitPushes || 0) : (push ? 1 : 0)),
      totalPlay: prev.totalPlay + totalPlay,
      totalWon: prev.totalWon + payout,
      biggestWin: Math.max(prev.biggestWin, payout),
      blackjacks: prev.blackjacks + (payload.blackjack ? 1 : 0),
      doubles: prev.doubles + (decision === "double" ? 1 : 0),
      splits: prev.splits + (splitResult ? 1 : 0),
      surrenders: prev.surrenders + (payload.surrender ? 1 : 0),
      insuranceWins: prev.insuranceWins + (insuranceTakenRef.current && !win && !push && payout > 0 ? 1 : 0),
      insuranceLosses: prev.insuranceLosses + (insuranceTakenRef.current && payout === 0 ? 1 : 0),
      lastPlay: baseStakeRef.current || prev.lastPlay,
    }));

    sessionIdRef.current = null;
    setSessionId(null);
    setGameState("finished");
    return { finishResult, payload };
  };

  useEffect(() => {
    let cancelled = false;
    setMounted(true);
    initSharedVault();
    readSharedVault()
      .then(snapshot => {
        if (!cancelled) setVaultState(snapshot.balance);
      })
      .catch(() => {
        if (!cancelled) setVaultState(peekSharedVault().balance);
      });
    const isFree = router.query.freePlay === 'true';
    setIsFreePlay(isFree);
    const gameId = router.pathname.replace('/', '') || 'blackjack';
    getFreePlayStatus().then(status => {
      if (!cancelled) setFreePlayTokens(status.tokens);
    }).catch(err => console.error('Failed to get free play status:', err));
    const savedStats = safeRead(LS_KEY, { lastPlay: MIN_PLAY });
    if (savedStats.lastPlay) setPlayAmount(String(savedStats.lastPlay));
    const unsubscribeVault = subscribeSharedVault(snapshot => {
      if (!cancelled) setVaultState(snapshot.balance);
    });
    const interval = setInterval(() => {
      getFreePlayStatus().then(status => {
        if (!cancelled) setFreePlayTokens(status.tokens);
      }).catch(err => console.error('Failed to get free play status:', err));
    }, 2000);
    if (typeof Audio !== "undefined") {
      try { clickSound.current = new Audio(S_CLICK); winSound.current = new Audio(S_WIN); } catch {}
    }
    const handleFullscreenChange = () => setIsFullscreen(!!document.fullscreenElement);
    document.addEventListener("fullscreenchange", handleFullscreenChange);
    return () => { cancelled = true; unsubscribeVault(); clearInterval(interval); document.removeEventListener("fullscreenchange", handleFullscreenChange); };
  }, [router.query]);

  useEffect(() => { safeWrite(LS_KEY, stats); }, [stats]);
  useEffect(() => { if (!wrapRef.current) return; const calc = () => { const rootH = window.visualViewport?.height ?? window.innerHeight; const safeBottom = Number(getComputedStyle(document.documentElement).getPropertyValue("--satb").replace("px", "")) || 0; const headH = headerRef.current?.offsetHeight || 0; document.documentElement.style.setProperty("--head-h", headH + "px"); const topPad = headH + 8; const used = headH + (metersRef.current?.offsetHeight || 0) + (betRef.current?.offsetHeight || 0) + (ctaRef.current?.offsetHeight || 0) + topPad + 48 + safeBottom + 24; const freeH = Math.max(200, rootH - used); document.documentElement.style.setProperty("--chart-h", freeH + "px"); }; calc(); window.addEventListener("resize", calc); window.visualViewport?.addEventListener("resize", calc); return () => { window.removeEventListener("resize", calc); window.visualViewport?.removeEventListener("resize", calc); }; }, [mounted]);
  useEffect(() => { if (gameResult) { setShowResultPopup(true); const timer = setTimeout(() => setShowResultPopup(false), 4000); return () => clearTimeout(timer); } }, [gameResult]);

  const openWalletModalUnified = () => isConnected ? openAccountModal?.() : openConnectModal?.();
  const hardDisconnect = () => { disconnect?.(); setMenuOpen(false); };

  const collectToWallet = async () => {
    if (!isConnected) { openConnectModal?.(); return; }
    if (chainId !== CLAIM_CHAIN_ID) { try { await switchChain?.({ chainId: CLAIM_CHAIN_ID }); } catch { alert("Switch to BSC Testnet"); return; } }
    if (!CLAIM_ADDRESS) { alert("Missing CLAIM address"); return; }
    const wholeCollectAmount = normalizeWholeAmount(collectAmount);
    if (wholeCollectAmount <= 0 || wholeCollectAmount > vault) { alert("Invalid amount!"); return; }
    setClaiming(true);
    try {
      const amountUnits = parseUnits(String(wholeCollectAmount), MLEO_DECIMALS);
      const hash = await writeContractAsync({ address: CLAIM_ADDRESS, abi: MINING_CLAIM_ABI, functionName: "claim", args: [BigInt(GAME_ID), amountUnits], chainId: CLAIM_CHAIN_ID, account: address });
      await publicClient.waitForTransactionReceipt({ hash });
      const debitResult = await applyVaultDebit(wholeCollectAmount, "blackjack-claim");
      if (!debitResult.ok) { alert(debitResult.error || "Vault update failed"); return; }
      setCollectAmount(wholeCollectAmount);
      alert(`✅ Sent ${fmt(wholeCollectAmount)} MLEO to wallet!`);
      setShowVaultModal(false);
    } catch (err) { console.error(err); alert("Claim failed or rejected"); } finally { setClaiming(false); }
  };

  const checkOpponentPerfect21 = async (opponent, player) => {
    const opponentVal = calculateHandValue(opponent);
    if (opponentVal === 21) {
      await finishBlackjackSession("play");
      return true;
    }
    return false;
  };

  const dealCards = async (isFreePlayParam = false) => {
    if (gameState !== "playing" && gameState !== "lobby" && gameState !== "finished") return;
    playSfx(clickSound.current);
    setSessionError("");
    let play = Number(playAmount) || MIN_PLAY;
    let nextSessionId = null;
    try {
      if (isFreePlay || isFreePlayParam) {
        const gameId = router.pathname.replace('/', '') || 'blackjack';
        const result = await startFreeplayArcadeSession(gameId);
        if (result.success) {
          play = Math.max(MIN_PLAY, Math.floor(Number(result.amount || 0) / RESERVED_STAKE_MULTIPLIER) || MIN_PLAY);
          nextSessionId = result.sessionId;
          setFreePlayTokens(result.remainingTokens);
          setIsFreePlay(false);
        } else {
          setSessionError("Failed to start session");
          alert(result.message || "No free play tokens available!");
          setIsFreePlay(false);
          return;
        }
      } else {
        if (play < MIN_PLAY) { alert(`Minimum play is ${MIN_PLAY} MLEO`); return; }
        const reservedStake = Math.floor(play * RESERVED_STAKE_MULTIPLIER);
        const startResult = await startPaidArcadeSession("blackjack", reservedStake);
        if (!startResult.success) {
          setSessionError("Failed to start session");
          alert(startResult.message || "Failed to start session");
          return;
        }
        nextSessionId = startResult.sessionId;
        setVaultState(startResult.balanceAfter);
      }

      if (!nextSessionId) {
        throw new Error("Missing session id");
      }
    } catch (error) {
      console.error("Blackjack start session error:", error);
      setSessionError(error?.message || "Failed to start session");
      if (isFreePlay || isFreePlayParam) {
        setIsFreePlay(false);
        alert(error?.message || "Failed to use free play token. Please try again.");
      } else {
        alert(error?.message || "Failed to start session");
      }
      return;
    }

    setPlayAmount(String(play));
    setSessionId(nextSessionId);
    sessionIdRef.current = nextSessionId;
    resetActionLog(play);

    // Reset all states
    setHasDoubled(false);
    setHasSurrendered(false);
    setShowInsurance(false);
    setInsuranceBet(0);
    setIsSplitGame(false);
    setSplitHands([]);
    setCurrentSplitIndex(0);
    const newDeck = createDeterministicCardDeck(nextSessionId);

    const player = [newDeck[0], newDeck[2]];
    const opponent = [newDeck[1], newDeck[3]];
    setDeck(newDeck.slice(4));
    
    // Clear cards first
    setPlayerHand([]);
    setOpponentHand([]);
    setGameResult(null);
    
    // Deal cards one by one - Opponent → Player → Opponent (hidden) → Player
    setTimeout(() => setOpponentHand([opponent[0]]), 400);
    setTimeout(() => setPlayerHand([player[0]]), 800);
    setTimeout(() => {
      setOpponentHand(opponent);
      setGameState("dealing"); // Temporary state to keep second card hidden
    }, 1200);
    setTimeout(() => {
      setPlayerHand(player);
      
      // Wait for last card animation (card delay 200ms + animation 400ms = 600ms) + extra pause to see cards (800ms)
      setTimeout(() => {
        // Check for perfect 21/insurance after all cards dealt AND animated AND visible
        const playerValue = calculateHandValue(player);
        const opponentUpCard = opponent[0];
        
        if (playerValue === 21) {
          // Player has perfect 21 - check if opponent also has it
          setTimeout(async () => {
            if (await checkOpponentPerfect21(opponent, player)) {
              return;
            }
            await finishBlackjackSession("play");
          }, 700);
          return;
        }
        
        if (opponentUpCard.value === "A") {
          setShowInsurance(true);
        }
        
        // Enable player options
        setCanDouble(true);
        setCanSplit(canSplitCards(player));
        setCanSurrender(true);
        
        setGameState("playing");
      }, 1400);
    }, 1600);
  };

  const takeInsurance = async () => {
    playSfx(clickSound.current);
    const play = Number(playAmount);
    const insuranceAmount = Math.floor(play / 2);
    insuranceTakenRef.current = true;
    setInsuranceBet(insuranceAmount);
    setShowInsurance(false);

    // Check for opponent perfect 21
    const opponentVal = calculateHandValue(opponentHand);
    if (opponentVal === 21) {
      await finishBlackjackSession("play");
      return;
    }

    setGameState("playing");
    setCanDouble(true);
    setCanSplit(canSplitCards(playerHand));
    setCanSurrender(true);
  };

  const declineInsurance = async () => {
    playSfx(clickSound.current);
    insuranceTakenRef.current = false;
    setShowInsurance(false);
    
    // Check for opponent perfect 21 anyway
    if (await checkOpponentPerfect21(opponentHand, playerHand)) {
      return;
    }

    setGameState("playing");
    setCanDouble(true);
    setCanSplit(canSplitCards(playerHand));
    setCanSurrender(true);
  };

  const doubleDown = async () => {
    if (!canDouble || gameState !== "playing") return;
    playSfx(clickSound.current);
    const play = Number(playAmount);
    setPlayAmount(String(play * 2));
    setHasDoubled(true);
    setCanDouble(false);
    setCanSplit(false);
    setCanSurrender(false);

    // Draw one card and stand
    if (!deck || deck.length === 0) {
      alert('Deck is empty! Please start a new game.');
      return;
    }
    const newCard = deck[0];
    const newHand = [...playerHand, newCard];
    setPlayerHand(newHand);
    setDeck(deck.slice(1));

    // Wait for card animation before checking
    setTimeout(() => {
      const value = calculateHandValue(newHand);
      if (value > 21) {
        setGameState("finished");
        setTimeout(() => finishBlackjackSession("double").catch((error) => {
          console.error("Blackjack finish session error:", error);
          setSessionError("Session failed to finish");
        }), 800);
      } else {
        stand(newHand, play * 2, true);
      }
    }, 600);

    const newStats = { ...stats, doubles: stats.doubles + 1 };
    setStats(newStats);
  };

  const split = async () => {
    if (!canSplit || gameState !== "playing") return;
    playSfx(clickSound.current);
    const play = Number(playAmount);
    setCanDouble(false);
    setCanSplit(false);
    setCanSurrender(false);
    setIsSplitGame(true);

    // Split into two hands
    if (!deck || deck.length < 2) {
      alert('Deck is empty! Please start a new game.');
      return;
    }
    const card1 = playerHand[0];
    const card2 = playerHand[1];
    const newCard1 = deck[0];
    const newCard2 = deck[1];
    
    const hand1 = [card1, newCard1];
    const hand2 = [card2, newCard2];
    
    setSplitHands([
      { cards: hand1, play: play, finished: false, result: null },
      { cards: hand2, play: play, finished: false, result: null }
    ]);
    setCurrentSplitIndex(0);
    setPlayerHand(hand1);
    setDeck(deck.slice(2));

    // Check if split aces - only one card each
    if (card1.value === "A") {
      // Split aces get only one card each - finish both hands
      setTimeout(() => finishSplitHands([
        { cards: hand1, play: play, finished: true, result: null },
        { cards: hand2, play: play, finished: true, result: null }
      ], play), 500);
    }

    const newStats = { ...stats, splits: stats.splits + 1 };
    setStats(newStats);
  };

  const finishSplitHands = (hands, individualBet) => {
    setGameState("opponent");
    let currentOpponentHand = [...opponentHand];
    let currentDeck = [...deck];

    // Opponent plays - one card at a time
    const opponentPlay = () => {
      let opponentValue = calculateHandValue(currentOpponentHand);
      
      const drawNextCard = () => {
        if (opponentValue >= 17) {
          // Opponent done - evaluate split hands
          setOpponentHand([...currentOpponentHand]);
          setDeck(currentDeck);
          
          setTimeout(() => {
            evaluateSplitResults(hands, currentOpponentHand, individualBet);
          }, 1200);
          return;
        }
        
        // Draw one card
        if (!currentDeck || currentDeck.length === 0) {
          setOpponentHand([...currentOpponentHand]);
          setDeck(currentDeck);
          setGameState("finished");
          setTimeout(() => {
            evaluateSplitResults();
          }, 1200);
          return;
        }
        currentOpponentHand.push(currentDeck[0]);
        currentDeck = currentDeck.slice(1);
        setOpponentHand([...currentOpponentHand]);
        setDeck(currentDeck);
        opponentValue = calculateHandValue(currentOpponentHand);
        
        // Wait for card animation, then draw next
        setTimeout(drawNextCard, 800);
      };
      
      drawNextCard();
    };
    
    setTimeout(opponentPlay, 500);
  };
  
  const evaluateSplitResults = async () => {
    await finishBlackjackSession("split");
  };

  const surrender = async () => {
    if (!canSurrender || gameState !== "playing") return;
    playSfx(clickSound.current);
    setHasSurrendered(true);
    setCanDouble(false);
    setCanSplit(false);
    setCanSurrender(false);
    try {
      await finishBlackjackSession("surrender");
    } catch (error) {
      console.error("Blackjack surrender session error:", error);
      setSessionError("Session failed to finish");
    }
  };

  const hit = () => {
    if (gameState !== "playing") return;
    playSfx(clickSound.current);
    
    // Disable special actions after first hit
    setCanDouble(false);
    setCanSurrender(false);

    if (isSplitGame) {
      if (currentSplitIndex === 0) splitHandOneActionsRef.current.push("hit");
      else splitHandTwoActionsRef.current.push("hit");
      if (!deck || deck.length === 0) {
        alert('Deck is empty! Please start a new game.');
        return;
      }
      const currentHand = splitHands[currentSplitIndex];
      const newCard = deck[0];
      const newCards = [...currentHand.cards, newCard];
      const newHands = [...splitHands];
      newHands[currentSplitIndex].cards = newCards;
      setSplitHands(newHands);
      setPlayerHand(newCards);
      setDeck(deck.slice(1));

      // Wait for card animation before checking bust
      setTimeout(() => {
        const value = calculateHandValue(newCards);
        if (value > 21) {
          // This hand busted, move to next
          newHands[currentSplitIndex].finished = true;
          setTimeout(() => {
            if (currentSplitIndex < splitHands.length - 1) {
              const nextIndex = currentSplitIndex + 1;
              setCurrentSplitIndex(nextIndex);
              setPlayerHand(splitHands[nextIndex].cards);
            } else {
              // All hands finished
              finishSplitHands(newHands, splitHands[0].play);
            }
          }, 800);
        } else if (value === 21) {
          // Stand automatically on 21
          standSplitHand();
        }
      }, 600);
    } else {
      actionsRef.current.push("hit");
      if (!deck || deck.length === 0) {
        alert('Deck is empty! Please start a new game.');
        return;
      }
      const newCard = deck[0];
      const newHand = [...playerHand, newCard];
      setPlayerHand(newHand);
      setDeck(deck.slice(1));

      // Wait for card animation before checking bust
      setTimeout(() => {
        const value = calculateHandValue(newHand);
        if (value > 21) {
          setGameState("finished");
          setTimeout(() => finishBlackjackSession("play").catch((error) => {
            console.error("Blackjack finish session error:", error);
            setSessionError("Session failed to finish");
          }), 800);
        } else if (value === 21) {
          stand(newHand);
        }
      }, 600);
    }
  };

  const standSplitHand = () => {
    if (currentSplitIndex === 0) splitHandOneActionsRef.current.push("stand");
    else splitHandTwoActionsRef.current.push("stand");
    const newHands = [...splitHands];
    newHands[currentSplitIndex].finished = true;
    setSplitHands(newHands);

    if (currentSplitIndex < splitHands.length - 1) {
      const nextIndex = currentSplitIndex + 1;
      setCurrentSplitIndex(nextIndex);
      setPlayerHand(splitHands[nextIndex].cards);
    } else {
      // All hands finished
      finishSplitHands(newHands, splitHands[0].play);
    }
  };

  const stand = (hand = null, customBet = null, isDouble = false) => {
    if (gameState !== "playing") return;
    playSfx(clickSound.current);
    
    if (isSplitGame) {
      standSplitHand();
      return;
    }

    setGameState("opponent");
    setCanDouble(false);
    setCanSplit(false);
    setCanSurrender(false);
    if (isDouble) {
      actionsRef.current.push("double");
    } else {
      actionsRef.current.push("stand");
    }

    const currentPlayerHand = hand || playerHand;
    const play = customBet || Number(playAmount);
    let currentOpponentHand = [...opponentHand];
    let currentDeck = [...deck];

    const opponentPlay = () => {
      let opponentValue = calculateHandValue(currentOpponentHand);
      
      const drawNextCard = () => {
        if (opponentValue >= 17) {
          // Opponent done - wait for last card animation + pause
          setOpponentHand([...currentOpponentHand]);
          setDeck(currentDeck);
          setGameState("finished");
          setTimeout(() => finishBlackjackSession(isDouble ? "double" : "play").catch((error) => {
            console.error("Blackjack finish session error:", error);
            setSessionError("Session failed to finish");
          }), 1200);
          return;
        }
        
        // Draw one card
        if (!currentDeck || currentDeck.length === 0) {
          setOpponentHand([...currentOpponentHand]);
          setDeck(currentDeck);
          setGameState("finished");
          setTimeout(() => finishBlackjackSession(isDouble ? "double" : "play").catch((error) => {
            console.error("Blackjack finish session error:", error);
            setSessionError("Session failed to finish");
          }), 1200);
          return;
        }
        currentOpponentHand.push(currentDeck[0]);
        currentDeck = currentDeck.slice(1);
        setOpponentHand([...currentOpponentHand]);
        setDeck(currentDeck);
        opponentValue = calculateHandValue(currentOpponentHand);
        
        // Wait for card animation, then draw next
        setTimeout(drawNextCard, 800);
      };
      
      drawNextCard();
    };

    setTimeout(opponentPlay, 500);
  };

  const newHand = () => { 
    setGameState("lobby"); 
    setPlayerHand([]);
    setOpponentHand([]);
    setGameResult(null); 
    setShowResultPopup(false);
    setCanDouble(false);
    setCanSplit(false);
    setCanSurrender(false);
    setShowInsurance(false);
    setInsuranceBet(0);
    setHasDoubled(false);
    setHasSurrendered(false);
    setIsSplitGame(false);
    setSplitHands([]);
    setCurrentSplitIndex(0);
    setSessionError("");
    setSessionId(null);
    sessionIdRef.current = null;
    resetActionLog(0);
  };

  const backSafe = () => { playSfx(clickSound.current); router.push('/arcade'); };

  if (!mounted) return <div className="min-h-screen bg-gradient-to-br from-red-900 via-black to-green-900 flex items-center justify-center"><div className="text-white text-xl">Loading...</div></div>;

  const playerValue = calculateHandValue(playerHand);
  const opponentValue = calculateHandValue(opponentHand);
  const potentialWin = Math.floor(Number(playAmount) * 2.5);

  return (
    <Layout>
      <style jsx>{`
        @keyframes slideInCard {
          from {
            opacity: 0;
            transform: translateX(-50px) scale(0.8);
          }
          to {
            opacity: 1;
            transform: translateX(0) scale(1);
          }
        }
      `}</style>
      <div ref={wrapRef} className="relative w-full overflow-hidden bg-gradient-to-br from-red-900 via-black to-green-900" style={{ height: '100svh' }}>
        <div className="absolute inset-0 opacity-10"><div className="absolute inset-0" style={{ backgroundImage: 'radial-gradient(circle, rgba(255,255,255,0.1) 1px, transparent 1px)', backgroundSize: '30px 30px' }} /></div>
        <div ref={headerRef} className="absolute top-0 left-0 right-0 z-50 pointer-events-none">
          <div className="relative px-2 py-3" style={{ paddingTop: "calc(env(safe-area-inset-top, 0px) + 10px)" }}>
            <div className="absolute left-2 top-2 flex gap-2 pointer-events-auto">
              <button onClick={backSafe} className="min-w-[60px] px-3 py-1 rounded-lg text-sm font-bold bg-white/5 border border-white/10 hover:bg-white/10">BACK</button>
              {freePlayTokens > 0 && (<button onClick={() => dealCards(true)} disabled={gameState !== "playing" && gameState !== "lobby" && gameState !== "finished"} className="relative px-2 py-1 rounded-lg bg-amber-500/20 border border-amber-500/40 hover:bg-amber-500/30 transition-all disabled:opacity-50" title={`${freePlayTokens} Free Play${freePlayTokens > 1 ? 's' : ''} Available`}><span className="text-base">🎁</span><span className="absolute -top-1 -right-1 bg-red-500 text-white text-xs font-bold rounded-full w-4 h-4 flex items-center justify-center">{freePlayTokens}</span></button>)}
            </div>
            <div className="absolute right-2 top-2 flex gap-2 pointer-events-auto">
              <button onClick={() => { playSfx(clickSound.current); const el = wrapRef.current || document.documentElement; if (!document.fullscreenElement) { el.requestFullscreen?.().catch(() => {}); } else { document.exitFullscreen?.().catch(() => {}); } }} className="min-w-[60px] px-3 py-1 rounded-lg text-sm font-bold bg-white/5 border border-white/10 hover:bg-white/10">{isFullscreen ? "EXIT" : "FULL"}</button>
              <button onClick={() => { playSfx(clickSound.current); setMenuOpen(true); }} className="min-w-[60px] px-3 py-1 rounded-lg text-sm font-bold bg-white/5 border border-white/10 hover:bg-white/10">MENU</button>
            </div>
          </div>
        </div>

        {sessionError ? (
          <div className="absolute top-[72px] left-1/2 -translate-x-1/2 z-40 px-3 py-1.5 rounded-lg bg-red-500/20 border border-red-500/40 text-red-200 text-sm">
            {sessionError}
          </div>
        ) : null}

        <div className="relative h-full flex flex-col items-center justify-start px-4 pb-4" style={{ minHeight: "100%", paddingTop: "calc(var(--head-h, 56px) + 8px)" }}>
          <div className="text-center mb-1">
            <h1 className="text-2xl font-extrabold text-white mb-0.5">♠️ 21 Challenge</h1>
            <p className="text-white/70 text-xs">Professional 21 Challenge • All Features!</p>
          </div>
          <div ref={metersRef} className="grid grid-cols-3 gap-1 mb-1 w-full max-w-md">
            <div className="bg-black/30 border border-white/10 rounded-lg p-1 text-center">
              <div className="text-[10px] text-white/60">Vault</div>
              <div className="text-sm font-bold text-emerald-400">{fmt(vault)}</div>
            </div>
            <div className="bg-black/30 border border-white/10 rounded-lg p-1 text-center">
              <div className="text-[10px] text-white/60">Play</div>
              <div className="text-sm font-bold text-amber-400">{fmt(Number(playAmount))}</div>
            </div>
            <div className="bg-black/30 border border-white/10 rounded-lg p-1 text-center">
              <div className="text-[10px] text-white/60">Max</div>
              <div className="text-sm font-bold text-green-400">{fmt(potentialWin)}</div>
            </div>
          </div>

          <div className="mb-1 w-full max-w-md flex flex-col items-center justify-center" style={{ height: "var(--chart-h, 300px)" }}>
            <div className="bg-black/20 border border-white/10 rounded-lg p-3 mb-2" style={{ minHeight: '110px' }}>
              <div className="text-xs text-white/60 mb-1">Opponent {gameState === "finished" && `(${opponentValue})`}</div>
              <div className="flex gap-1 flex-wrap min-h-[80px]">
                {opponentHand.map((card, i) => (
                  <PlayingCard key={i} card={card} hidden={(gameState === "playing" || gameState === "insurance" || gameState === "dealing") && i === 1} delay={i * 200} />
                ))}
              </div>
            </div>
            <div className="bg-black/20 border border-white/10 rounded-lg p-3" style={{ minHeight: '110px' }}>
              <div className="text-xs text-white/60 mb-1">You {gameState !== "playing" && gameState !== "insurance" && gameState !== "dealing" && `(${playerValue})`} {isSplitGame && `- Hand ${currentSplitIndex + 1}/2`}</div>
              <div className="flex gap-1 flex-wrap min-h-[80px]">
                {playerHand.map((card, i) => (
                  <PlayingCard key={i} card={card} delay={i * 200} />
                ))}
              </div>
            </div>
            <div className="text-center mt-2" style={{ height: '28px' }}>
              <div className={`text-base font-bold transition-opacity ${gameResult ? 'opacity-100' : 'opacity-0'} ${gameResult?.win ? 'text-green-400' : gameResult?.push ? 'text-yellow-400' : 'text-red-400'}`}>
                {gameResult ? (
                  gameResult.surrender ? 'SURRENDERED' :
                  gameResult.split ? `${gameResult.splitWins}W ${gameResult.splitLosses}L ${gameResult.splitPushes}P` :
                  gameResult.blackjack ? 'PERFECT 21!' : 
                  gameResult.push ? 'PUSH' : 
                  gameResult.win ? 'YOU WIN!' : 
                  'OPPONENT WINS'
                ) : 'waiting'}
              </div>
            </div>
          </div>

          <div ref={betRef} className="flex items-center justify-center gap-1 mb-1 flex-wrap" style={{ minHeight: '48px' }}>
            <button onClick={() => { const current = Number(playAmount) || MIN_PLAY; const newBet = current === MIN_PLAY ? Math.min(vault, 100) : Math.min(vault, current + 100); setPlayAmount(String(newBet)); playSfx(clickSound.current); }} disabled={gameState === "playing" || gameState === "opponent" || gameState === "dealing"} className="w-12 h-8 rounded-lg bg-white/10 hover:bg-white/20 text-white font-bold text-xs disabled:opacity-50">100</button>
            <button onClick={() => { const current = Number(playAmount) || MIN_PLAY; const newBet = current === MIN_PLAY ? Math.min(vault, 1000) : Math.min(vault, current + 1000); setPlayAmount(String(newBet)); playSfx(clickSound.current); }} disabled={gameState === "playing" || gameState === "opponent" || gameState === "dealing"} className="w-12 h-8 rounded-lg bg-white/10 hover:bg-white/20 text-white font-bold text-xs disabled:opacity-50">1K</button>
            <button onClick={() => { const current = Number(playAmount) || MIN_PLAY; const newBet = current === MIN_PLAY ? Math.min(vault, 10000) : Math.min(vault, current + 10000); setPlayAmount(String(newBet)); playSfx(clickSound.current); }} disabled={gameState === "playing" || gameState === "opponent" || gameState === "dealing"} className="w-12 h-8 rounded-lg bg-white/10 hover:bg-white/20 text-white font-bold text-xs disabled:opacity-50">10K</button>
            <button onClick={() => { const current = Number(playAmount) || MIN_PLAY; const newBet = current === MIN_PLAY ? Math.min(vault, 100000) : Math.min(vault, current + 100000); setPlayAmount(String(newBet)); playSfx(clickSound.current); }} disabled={gameState === "playing" || gameState === "opponent" || gameState === "dealing"} className="w-12 h-8 rounded-lg bg-white/10 hover:bg-white/20 text-white font-bold text-xs disabled:opacity-50">100K</button>
            <button onClick={() => { const current = Number(playAmount) || MIN_PLAY; const newBet = Math.max(MIN_PLAY, current - 100); setPlayAmount(String(newBet)); playSfx(clickSound.current); }} disabled={gameState === "playing" || gameState === "opponent" || gameState === "dealing"} className="h-8 w-8 rounded-lg bg-white/10 hover:bg-white/20 text-white font-bold text-sm disabled:opacity-50">−</button>
            <div className="relative">
              <input type="text" value={isEditingPlay ? playAmount : formatPlayDisplay(playAmount)} onFocus={() => setIsEditingPlay(true)} onChange={(e) => { const val = e.target.value.replace(/[^0-9]/g, ''); setPlayAmount(val || '0'); }} onBlur={() => { setIsEditingPlay(false); const current = Number(playAmount) || MIN_PLAY; setPlayAmount(String(Math.max(MIN_PLAY, current))); }} disabled={gameState === "playing" || gameState === "opponent" || gameState === "dealing"} className="w-20 h-8 bg-black/30 border border-white/20 rounded-lg text-center text-white font-bold text-xs disabled:opacity-50 pr-6" />
              <button onClick={() => { setPlayAmount(String(MIN_PLAY)); playSfx(clickSound.current); }} disabled={gameState === "playing" || gameState === "opponent" || gameState === "dealing"} className="absolute right-1 top-1/2 transform -translate-y-1/2 h-6 w-6 rounded bg-red-500/20 hover:bg-red-500/30 text-red-400 font-bold text-xs disabled:opacity-50 flex items-center justify-center" title="Reset to minimum play">↺</button>
            </div>
            <button onClick={() => { const current = Number(playAmount) || MIN_PLAY; const newBet = Math.min(vault, current + 1000); setPlayAmount(String(newBet)); playSfx(clickSound.current); }} disabled={gameState === "playing" || gameState === "opponent" || gameState === "dealing"} className="h-8 w-8 rounded-lg bg-white/10 hover:bg-white/20 text-white font-bold text-sm disabled:opacity-50">+</button>
          </div>

          <div ref={ctaRef} className="flex flex-col gap-3 w-full max-w-sm" style={{ minHeight: "140px" }}>
            {gameState === "playing" && playerHand.length > 0 ? (
              <div className="w-full flex gap-1">
                <button onClick={hit} className="flex-1 h-12 rounded-lg font-bold text-xs bg-gradient-to-r from-blue-500 to-blue-600 text-white shadow-lg hover:brightness-110">HIT</button>
                <button onClick={() => stand()} className="flex-1 h-12 rounded-lg font-bold text-xs bg-gradient-to-r from-orange-500 to-orange-600 text-white shadow-lg hover:brightness-110">STAND</button>
                <button onClick={doubleDown} disabled={!canDouble} className="flex-1 h-12 rounded-lg font-bold text-[10px] bg-gradient-to-r from-purple-500 to-purple-600 text-white shadow-lg hover:brightness-110 disabled:opacity-30 disabled:cursor-not-allowed">DOUBLE</button>
                <button onClick={split} disabled={!canSplit} className="flex-1 h-12 rounded-lg font-bold text-[10px] bg-gradient-to-r from-pink-500 to-pink-600 text-white shadow-lg hover:brightness-110 disabled:opacity-30 disabled:cursor-not-allowed">SPLIT</button>
                <button onClick={surrender} disabled={!canSurrender} className="flex-1 h-12 rounded-lg font-bold text-[10px] bg-gradient-to-r from-gray-500 to-gray-600 text-white shadow-lg hover:brightness-110 disabled:opacity-30 disabled:cursor-not-allowed">SURR</button>
              </div>
            ) : (
              <button onClick={gameState === "finished" ? newHand : () => dealCards(false)} disabled={gameState === "opponent" || gameState === "dealing"} className="w-full h-12 rounded-lg font-bold text-base bg-gradient-to-r from-red-500 to-green-600 text-white shadow-lg hover:brightness-110 transition-all disabled:opacity-50">
                {gameState === "opponent" || gameState === "dealing" ? "Dealing..." : gameState === "finished" ? "NEW HAND" : "DEAL"}
              </button>
            )}
            <div className="flex gap-2">
              <button onClick={() => { setShowHowToPlay(true); playSfx(clickSound.current); }} className="flex-1 py-2 rounded-lg bg-blue-500/20 border border-blue-500/30 text-blue-300 hover:bg-blue-500/30 font-semibold text-xs transition-all">How to Play</button>
              <button onClick={() => { setShowStats(true); playSfx(clickSound.current); }} className="flex-1 py-2 rounded-lg bg-purple-500/20 border border-purple-500/30 text-purple-300 hover:bg-purple-500/30 font-semibold text-xs transition-all">Stats</button>
              <button onClick={() => { setShowVaultModal(true); playSfx(clickSound.current); }} className="flex-1 py-2 rounded-lg bg-emerald-500/20 border border-emerald-500/30 text-emerald-300 hover:bg-emerald-500/30 font-semibold text-xs transition-all">💰 Vault</button>
            </div>
          </div>
        </div>

        {showResultPopup && gameResult && (
          <div className="fixed inset-0 z-[9999] flex items-center justify-center pointer-events-none">
            <div className={`${gameResult.win ? 'bg-green-500' : gameResult.push ? 'bg-yellow-500' : 'bg-red-500'} text-white px-8 py-6 rounded-2xl shadow-2xl text-center pointer-events-auto`} style={{ animation: 'fadeIn 0.3s ease-in-out' }}>
              <div className="text-4xl mb-2">
                {gameResult.blackjack ? '💎' : gameResult.surrender ? '🏳️' : gameResult.split ? '✂️' : gameResult.win ? '🎉' : gameResult.push ? '🤝' : '😔'}
              </div>
              <div className="text-2xl font-bold mb-1">
                {gameResult.surrender ? 'SURRENDERED' : gameResult.split ? `SPLIT: ${gameResult.splitWins}W ${gameResult.splitLosses}L` : gameResult.blackjack ? 'PERFECT 21!' : gameResult.win ? 'YOU WIN!' : gameResult.push ? 'PUSH' : 'OPPONENT WINS'}
              </div>
              <div className="text-lg">
                {gameResult.win || gameResult.push ? `+${fmt(gameResult.prize)} MLEO` : `-${fmt(Math.abs(gameResult.profit))} MLEO`}
              </div>
              {!gameResult.surrender && !gameResult.split && (
                <div className="text-sm opacity-80 mt-2">You: {gameResult.playerValue} • Opponent: {gameResult.opponentValue}</div>
              )}
              {gameResult.insurance && <div className="text-sm opacity-80 mt-1">🛡️ Insurance Paid!</div>}
            </div>
          </div>
        )}

        {menuOpen && (
          <div className="fixed inset-0 z-[10000] bg-black/60 flex items-center justify-center p-3" onClick={() => setMenuOpen(false)}>
            <div className="w-[86vw] max-w-[250px] max-h-[70vh] bg-[#0b1220] text-white shadow-2xl rounded-2xl p-4 md:p-5 overflow-y-auto" onClick={(e) => e.stopPropagation()}>
              <div className="flex items-center justify-between mb-2 md:mb-3">
                <h2 className="text-xl font-extrabold">Settings</h2>
                <button onClick={() => setMenuOpen(false)} className="h-9 w-9 rounded-lg bg-white/10 hover:bg-white/20 grid place-items-center">✕</button>
              </div>
              <div className="mb-3 space-y-2">
                <h3 className="text-sm font-semibold opacity-80">Wallet</h3>
                <div className="flex items-center gap-2">
                  <button onClick={openWalletModalUnified} className={`px-3 py-2 rounded-md text-sm font-semibold ${isConnected ? "bg-emerald-500/90 hover:bg-emerald-500 text-white" : "bg-rose-500/90 hover:bg-rose-500 text-white"}`}>
                    {isConnected ? "Connected" : "Disconnected"}
                  </button>
                  {isConnected && (
                    <button onClick={hardDisconnect} className="px-3 py-2 rounded-md text-sm font-semibold bg-rose-500/90 hover:bg-rose-500 text-white">Disconnect</button>
                  )}
                </div>
                {isConnected && address && (
                  <button onClick={() => { try { navigator.clipboard.writeText(address).then(() => { setCopiedAddr(true); setTimeout(() => setCopiedAddr(false), 1500); }); } catch {} }} className="mt-1 text-xs text-gray-300 hover:text-white transition underline">
                    {shortAddr(address)}
                    {copiedAddr && <span className="ml-2 text-emerald-400">Copied!</span>}
                  </button>
                )}
              </div>
              <div className="mb-4 space-y-2">
                <h3 className="text-sm font-semibold opacity-80">Sound</h3>
                <button onClick={() => setSfxMuted(v => !v)} className={`px-3 py-2 rounded-lg text-sm font-semibold ${sfxMuted ? "bg-rose-500/90 hover:bg-rose-500 text-white" : "bg-emerald-500/90 hover:bg-emerald-500 text-white"}`}>
                  SFX: {sfxMuted ? "Off" : "On"}
                </button>
              </div>
              <div className="mt-4 text-xs opacity-70">
                <p>21 Challenge v3.0</p>
              </div>
            </div>
          </div>
        )}

        {showHowToPlay && (
          <div className="fixed inset-0 z-[10000] bg-black/80 flex items-center justify-center p-4">
            <div className="bg-zinc-900 text-white max-w-md w-full rounded-2xl p-6 shadow-2xl max-h-[85vh] overflow-auto">
              <h2 className="text-2xl font-extrabold mb-4">♠️ How to Play</h2>
              <div className="space-y-3 text-sm">
                <p><strong>Basic Rules:</strong></p>
                <p>• Get closer to 21 than opponent without busting</p>
                <p>• Opponent hits until 17+</p>
                <p><strong>Actions:</strong></p>
                <p>• <strong>HIT:</strong> Take another card</p>
                <p>• <strong>STAND:</strong> Keep your hand</p>
                <p>• <strong>DOUBLE:</strong> Double play, get 1 card</p>
                <p>• <strong>SPLIT:</strong> Split pairs into 2 hands</p>
                <p>• <strong>SURRENDER:</strong> Forfeit & get ½ play back</p>
                <p>• <strong>INSURANCE:</strong> Protect vs opponent Ace</p>
                <div className="bg-red-500/10 border border-red-500/30 rounded-lg p-3">
                  <p className="text-red-300 font-semibold">Prizes:</p>
                  <div className="text-xs text-white/80 mt-2 space-y-1">
                    <p>• Perfect 21: ×2.5 💎</p>
                    <p>• Win: ×2</p>
                    <p>• Push: Money back</p>
                    <p>• Insurance: ×2 (if opponent BJ)</p>
                  </div>
                </div>
              </div>
              <button onClick={() => setShowHowToPlay(false)} className="w-full mt-6 py-3 rounded-lg bg-white/10 hover:bg-white/20 font-bold">Close</button>
            </div>
          </div>
        )}

        {showStats && (
          <div className="fixed inset-0 z-[10000] bg-black/80 flex items-center justify-center p-4">
            <div className="bg-zinc-900 text-white max-w-md w-full rounded-2xl p-6 shadow-2xl max-h-[85vh] overflow-auto">
              <h2 className="text-2xl font-extrabold mb-4">📊 Your Statistics</h2>
              <div className="space-y-3">
                <div className="grid grid-cols-2 gap-3">
                  <div className="bg-black/30 border border-white/10 rounded-lg p-3">
                    <div className="text-xs text-white/60">Total Hands</div>
                    <div className="text-xl font-bold">{stats.totalHands}</div>
                  </div>
                  <div className="bg-black/30 border border-white/10 rounded-lg p-3">
                    <div className="text-xs text-white/60">Win Rate</div>
                    <div className="text-xl font-bold text-green-400">
                      {stats.totalHands > 0 ? ((stats.wins / stats.totalHands) * 100).toFixed(1) : 0}%
                    </div>
                  </div>
                  <div className="bg-black/30 border border-white/10 rounded-lg p-3">
                    <div className="text-xs text-white/60">Perfect 21s</div>
                    <div className="text-lg font-bold text-yellow-400">{stats.blackjacks} 💎</div>
                  </div>
                  <div className="bg-black/30 border border-white/10 rounded-lg p-3">
                    <div className="text-xs text-white/60">Doubles</div>
                    <div className="text-lg font-bold text-purple-400">{stats.doubles}</div>
                  </div>
                  <div className="bg-black/30 border border-white/10 rounded-lg p-3">
                    <div className="text-xs text-white/60">Splits</div>
                    <div className="text-lg font-bold text-pink-400">{stats.splits}</div>
                  </div>
                  <div className="bg-black/30 border border-white/10 rounded-lg p-3">
                    <div className="text-xs text-white/60">Surrenders</div>
                    <div className="text-lg font-bold text-gray-400">{stats.surrenders}</div>
                  </div>
                  <div className="bg-black/30 border border-white/10 rounded-lg p-3">
                    <div className="text-xs text-white/60">Total Play</div>
                    <div className="text-lg font-bold text-amber-400">{fmt(stats.totalPlay)}</div>
                  </div>
                  <div className="bg-black/30 border border-white/10 rounded-lg p-3">
                    <div className="text-xs text-white/60">Total Won</div>
                    <div className="text-lg font-bold text-emerald-400">{fmt(stats.totalWon)}</div>
                  </div>
                  <div className="bg-black/30 border border-white/10 rounded-lg p-3">
                    <div className="text-xs text-white/60">Biggest Win</div>
                    <div className="text-lg font-bold text-yellow-400">{fmt(stats.biggestWin)}</div>
                  </div>
                  <div className="bg-black/30 border border-white/10 rounded-lg p-3">
                    <div className="text-xs text-white/60">Net Profit</div>
                    <div className={`text-lg font-bold ${stats.totalWon - stats.totalPlay >= 0 ? 'text-green-400' : 'text-red-400'}`}>
                      {fmt(stats.totalWon - stats.totalPlay)}
                    </div>
                  </div>
                </div>
                <div className="bg-gradient-to-r from-blue-500/10 to-yellow-500/10 border border-blue-500/30 rounded-lg p-4">
                  <div className="text-sm font-semibold mb-2">🛡️ Insurance</div>
                  <div className="text-center">
                    <div className="text-2xl font-bold text-blue-300">{stats.insuranceWins}W / {stats.insuranceLosses}L</div>
                    <div className="text-xs text-white/60 mt-1">Insurance Plays</div>
                  </div>
                </div>
              </div>
              <button onClick={() => setShowStats(false)} className="w-full mt-6 py-3 rounded-lg bg-white/10 hover:bg-white/20 font-bold">Close</button>
            </div>
          </div>
        )}

        {showVaultModal && (
          <div className="fixed inset-0 z-[10000] bg-black/80 flex items-center justify-center p-4">
            <div className="bg-zinc-900 text-white max-w-md w-full rounded-2xl p-6 shadow-2xl max-h-[85vh] overflow-auto">
              <h2 className="text-2xl font-extrabold mb-4">💰 MLEO Vault</h2>
              <div className="bg-emerald-500/10 border border-emerald-500/30 rounded-lg p-4 mb-6 text-center">
                <div className="text-sm text-white/60 mb-1">Current Balance</div>
                <div className="text-3xl font-bold text-emerald-400">{fmt(vault)} MLEO</div>
              </div>
              <div className="space-y-4">
                <div>
                  <label className="text-sm text-white/70 mb-2 block">Collect to Wallet</label>
                  <div className="flex gap-2 mb-2">
                    <input type="number" value={collectAmount} onChange={(e) => setCollectAmount(normalizeWholeAmount(e.target.value))} className="flex-1 px-3 py-2 rounded-lg bg-black/30 border border-white/20 text-white" min="1" step="1" max={vault} />
                    <button onClick={() => setCollectAmount(vault)} className="px-4 py-2 rounded-lg bg-white/10 hover:bg-white/20 text-sm font-semibold">MAX</button>
                  </div>
                  <button onClick={collectToWallet} disabled={collectAmount <= 0 || collectAmount > vault || claiming} className="w-full py-3 rounded-lg bg-emerald-500 hover:bg-emerald-600 text-white font-bold disabled:opacity-50 disabled:cursor-not-allowed">
                    {claiming ? "Collecting..." : `Collect ${fmt(collectAmount)} MLEO`}
                  </button>
                </div>
                <div className="text-xs text-white/60">
                  <p>• Your vault is shared across all MLEO games</p>
                  <p>• Collect earnings to your wallet anytime</p>
                  <p>• Network: BSC Testnet (TBNB)</p>
                </div>
              </div>
              <button onClick={() => setShowVaultModal(false)} className="w-full mt-6 py-3 rounded-lg bg-white/10 hover:bg-white/20 font-bold">Close</button>
            </div>
          </div>
        )}

        {showInsurance && (
          <div className="fixed inset-0 z-[10000] bg-black/80 flex items-center justify-center p-4">
            <div className="bg-yellow-500/20 border-2 border-yellow-500/50 rounded-xl p-6 text-center max-w-md w-full shadow-2xl animate-pulse">
              <div className="text-2xl font-bold text-yellow-300 mb-3">🛡️ Insurance?</div>
              <div className="text-base text-white/90 mb-3">
                Opponent has Ace. Protect against Perfect 21?
              </div>
              <div className="text-sm text-white/70 mb-4">
                Cost: {fmt(Math.floor(Number(playAmount) / 2))} MLEO
              </div>
              <div className="flex gap-3">
                <button onClick={takeInsurance} className="flex-1 py-3 rounded-lg bg-green-500 hover:bg-green-600 text-white font-bold">
                  YES
                </button>
                <button onClick={declineInsurance} className="flex-1 py-3 rounded-lg bg-red-500 hover:bg-red-600 text-white font-bold">
                  NO
                </button>
              </div>
            </div>
          </div>
        )}
      </div>
    </Layout>
  );
}
