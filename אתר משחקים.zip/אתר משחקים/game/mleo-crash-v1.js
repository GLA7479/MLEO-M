// ============================================================================
// pages/mleo-crash.js
// MLEO Sky Run — full single-file Next.js page
// - 30s playing phase
// - Live multiplier chart (SVG)
// - Cash Out before crash to win play * multiplier
// - Provably-fair demo: serverSeedHash shown before round; serverSeed revealed after
// Design: TailwindCSS (assumed present), no external libs
// Hooks-safe (no conditional hooks), mobile-friendly
// ============================================================================

import { useEffect, useMemo, useRef, useState } from "react";
import { useRouter } from "next/router";
import Layout from "../components/Layout";
import Link from "next/link";
import { useFreePlayToken, getFreePlayStatus } from "../lib/free-play-system";

// ------------------------------- Storage -------------------------------------
const LS_KEY = "mleo_crash_v1";
const MIN_PLAY = 1000;

function safeRead(key, fallback = {}) {
  if (typeof window === "undefined") return fallback;
  try {
    const raw = window.localStorage.getItem(key);
    return raw ? JSON.parse(raw) : fallback;
  } catch {
    return fallback;
  }
}

function safeWrite(key, val) {
  if (typeof window === "undefined") return;
  try {
    window.localStorage.setItem(key, JSON.stringify(val));
  } catch {}
}

function getVault() {
  const rushData = safeRead("mleo_rush_core_v4", {});
  return rushData.vault || 0;
}

function setVault(amount) {
  const rushData = safeRead("mleo_rush_core_v4", {});
  rushData.vault = amount;
  safeWrite("mleo_rush_core_v4", rushData);
}

function fmt(n) {
  if (n >= 1e6) return (n / 1e6).toFixed(2) + "M";
  if (n >= 1e3) return (n / 1e3).toFixed(2) + "K";
  return Math.floor(n).toString();
}

// ------------------------------- Config -------------------------------------
const ROUND = {
  bettingSeconds: 30,           // time for all players to play
  intermissionMs: 4000,         // pause after round ends before next playing opens
  fps: 60,                      // animation FPS
  decimals: 2,                  // display precision
  minCrash: 1.1,                // min crash multiplier inclusive
  maxCrash: 10.0,               // max crash multiplier inclusive
  // growth: multiplier function as a function of elapsed ms since takeoff
  growth: (elapsedMs) => {
    // Smooth exponential-ish growth starting at 1.00
    const t = elapsedMs / 1000;             // seconds
    const rate = 0.85;                       // tune feel
    const m = Math.exp(rate * t * 0.6);      // ~1.00 -> 2x in ~1.2-1.5s (tunable)
    return Math.max(1, m);
  },
};

// ---------------------------- Helpers (provably fair) ------------------------
async function sha256Hex(str) {
  const enc = new TextEncoder();
  const data = enc.encode(str);
  const digest = await crypto.subtle.digest("SHA-256", data);
  return [...new Uint8Array(digest)].map((b) => b.toString(16).padStart(2, "0")).join("");
}

/** Map 256-bit hash to [0,1) float */
function hashToUnitFloat(hex) {
  // take first 13 hex chars (~52 bits) to stay within JS number precision
  const slice = hex.slice(0, 13);
  const int = parseInt(slice, 16);
  const max = Math.pow(16, slice.length);
  return int / max; // in [0,1)
}

/** Map hash to crash point in [minCrash, maxCrash] with slight skew toward early busts */
function hashToCrash(hex, minCrash, maxCrash) {
  const u = hashToUnitFloat(hex);
  // Skew: y = u^k (k>1 favors earlier crashes). Tune k=1.45
  const k = 1.45;
  const skew = Math.pow(u, k);
  const v = minCrash + (maxCrash - minCrash) * skew;
  // clamp & 2 decimals
  return Math.max(minCrash, Math.min(maxCrash, Math.round(v * 100) / 100));
}

// ------------------------------ UI Atoms ------------------------------------
function StatBox({ label, value, sub }) {
  return (
    <div className="flex flex-col items-center justify-center rounded-2xl bg-zinc-800/70 px-4 py-3 shadow">
      <div className="text-zinc-400 text-xs uppercase tracking-wider">{label}</div>
      <div className="text-white text-xl font-semibold mt-1">{value}</div>
      {sub ? <div className="text-zinc-500 text-xs mt-0.5">{sub}</div> : null}
    </div>
  );
}

// ------------------------------ Main Page -----------------------------------
export default function MLEOCrash() {
  const router = useRouter();
  const [mounted, setMounted] = useState(false);
  
  // Game state
  const [phase, setPhase] = useState("playing"); // playing | running | crashed | revealing | intermission
  const [countdown, setCountdown] = useState(ROUND.bettingSeconds);
  const [playAmount, setPlayAmount] = useState("1000");
  const [playerBet, setPlayerBet] = useState(null); // { amount:number, accepted:boolean }
  const [canCashOut, setCanCashOut] = useState(false);
  const [cashedOutAt, setCashedOutAt] = useState(null); // multiplier at cashout
  const [prize, setPayout] = useState(null);

  // Provably-fair data (client demo)
  const [serverSeed, setServerSeed] = useState("");        // revealed after round
  const [serverSeedHash, setServerSeedHash] = useState(""); // shown before round
  const [clientSeed, setClientSeed] = useState(() => Math.random().toString(36).slice(2));
  const [nonce, setNonce] = useState(0);
  const [crashPoint, setCrashPoint] = useState(null);

  // Live chart/multiplier
  const [multiplier, setMultiplier] = useState(1.0);
  const startTimeRef = useRef(0);
  const rafRef = useRef(0);
  const dataRef = useRef([]); // sampled points for chart

  // Vault & Free Play
  const [vault, setVaultState] = useState(0);
  const [isFreePlay, setIsFreePlay] = useState(false);
  const [freePlayTokens, setFreePlayTokens] = useState(0);
  const [showResultPopup, setShowResultPopup] = useState(false);
  const [stats, setStats] = useState(() => 
    safeRead(LS_KEY, { totalGames: 0, totalPlay: 0, totalWon: 0, biggestWin: 0, wins: 0, lastPlay: MIN_PLAY })
  );

  // ----------------------- Init -------------------
  useEffect(() => {
    setMounted(true);
    setVaultState(getVault());
    
    const isFree = router.query.freePlay === 'true';
    setIsFreePlay(isFree);
    
    const freePlayStatus = getFreePlayStatus();
    setFreePlayTokens(freePlayStatus.tokens);
    
    const savedStats = safeRead(LS_KEY, { lastPlay: MIN_PLAY });
    if (savedStats.lastPlay) {
      setPlayAmount(String(savedStats.lastPlay));
    }
    
    const interval = setInterval(() => {
      const status = getFreePlayStatus();
      setFreePlayTokens(status.tokens);
    }, 2000);
    
    return () => clearInterval(interval);
  }, [router.query]);

  useEffect(() => {
    if (prize) {
      setShowResultPopup(true);
      const timer = setTimeout(() => {
        setShowResultPopup(false);
      }, 4000);
      return () => clearTimeout(timer);
    }
  }, [prize]);

  const refreshVault = () => {
    setVaultState(getVault());
  };

  // ----------------------- Lifecycle: start playing window -------------------
  useEffect(() => {
    // Fresh seeds for the upcoming round
    // serverSeed kept secret until reveal; we show only its hash now.
    (async () => {
      const newServerSeed = crypto.getRandomValues(new Uint32Array(8)).join("-");
      const hash = await sha256Hex(newServerSeed);
      setServerSeed(newServerSeed);
      setServerSeedHash(hash);
      setCrashPoint(null);
      setCashedOutAt(null);
      setPayout(null);
      setPlayerBet(null);
      setCanCashOut(false);
      dataRef.current = [];
      setMultiplier(1.0);
      setNonce((n) => n + 1);
    })();

    // 30s countdown
    setPhase("playing");
    setCountdown(ROUND.bettingSeconds);
    const id = setInterval(() => {
      setCountdown((c) => {
        if (c <= 1) {
          clearInterval(id);
        }
        return c - 1;
      });
    }, 1000);
    return () => clearInterval(id);
  }, []); // run once on mount

  // When playing ends -> lock plays and takeoff
  useEffect(() => {
    if (phase !== "playing") return;
    if (countdown <= 0) {
      // Lock play (accept if placed)
      if (playerBet && !playerBet.accepted) {
        setPlayerBet({ ...playerBet, accepted: true });
      }
      // Compute crash from provably-fair hash(serverSeed + clientSeed + nonce)
      (async () => {
        const h = await sha256Hex(`${serverSeed}|${clientSeed}|${nonce}`);
        const crash = hashToCrash(h, ROUND.minCrash, ROUND.maxCrash);
        setCrashPoint(crash);
        // Start live run
        setPhase("running");
        takeoff();
      })();
    }
  }, [countdown, phase, playerBet, serverSeed, clientSeed, nonce]);

  // ------------------------------- Engine -----------------------------------
  const takeoff = () => {
    startTimeRef.current = performance.now();
    setCanCashOut(true);
    cancelAnimationFrame(rafRef.current);

    const tick = () => {
      const now = performance.now();
      const elapsed = now - startTimeRef.current;
      const m = ROUND.growth(elapsed);
      const mFixed = Math.max(1, Math.floor(m * Math.pow(10, ROUND.decimals)) / Math.pow(10, ROUND.decimals));
      setMultiplier(mFixed);

      // sample for chart (cap samples)
      dataRef.current.push({ t: elapsed, m: mFixed });
      if (dataRef.current.length > 800) dataRef.current.shift();

      // Crash?
      if (crashPoint && mFixed >= crashPoint) {
        setMultiplier(crashPoint);
        setPhase("crashed");
        setCanCashOut(false);
        cancelAnimationFrame(rafRef.current);
        // Resolve loss if not cashed out
        if (!cashedOutAt && playerBet?.accepted) {
          // no prize
          setPayout({ win: false, amount: 0, at: crashPoint });
          
          // Update stats for loss
          const newStats = {
            ...stats,
            totalGames: stats.totalGames + 1,
            totalPlay: stats.totalPlay + playerBet.amount,
            lastPlay: playerBet.amount
          };
          setStats(newStats);
          safeWrite(LS_KEY, newStats);
        }
        // Reveal seeds a moment later
        setTimeout(() => setPhase("revealing"), 600);
        // After short intermission → next playing window
        setTimeout(() => startNextRound(), 600 + ROUND.intermissionMs);
        return;
      }

      rafRef.current = requestAnimationFrame(tick);
    };
    rafRef.current = requestAnimationFrame(tick);
  };

  const startNextRound = async () => {
    // Reveal already occurred; now reset to new playing window
    // New seeds:
    const newServerSeed = crypto.getRandomValues(new Uint32Array(8)).join("-");
    const hash = await sha256Hex(newServerSeed);
    setServerSeed(newServerSeed);
    setServerSeedHash(hash);
    setClientSeed(Math.random().toString(36).slice(2));
    setNonce((n) => n + 1);
    setCrashPoint(null);
    setMultiplier(1.0);
    dataRef.current = [];
    setCashedOutAt(null);
    setPayout(null);
    setPlayerBet(null);
    setCanCashOut(false);

    setPhase("playing");
    setCountdown(ROUND.bettingSeconds);
    const id = setInterval(() => {
      setCountdown((c) => {
        if (c <= 1) clearInterval(id);
        return c - 1;
      });
    }, 1000);
  };

  // ------------------------------- Actions ----------------------------------
  const placeBet = (isFreePlayParam = false) => {
    let amt = Number(playAmount) || MIN_PLAY;
    if (!Number.isFinite(amt) || amt < MIN_PLAY) return;
    if (phase !== "playing") return;
    
    if (isFreePlay || isFreePlayParam) {
      const result = useFreePlayToken();
      if (result.success) {
        amt = result.amount;
        setIsFreePlay(false);
        router.replace('/crash2', undefined, { shallow: true });
        setPlayerBet({ amount: amt, accepted: false });
      } else {
        alert('No free play tokens available!');
        setIsFreePlay(false);
        return;
      }
    } else {
      const currentVault = getVault();
      if (amt > currentVault) {
        alert('Insufficient MLEO in vault');
        return;
      }

      // Deduct from vault
      setVault(currentVault - amt);
      setVaultState(currentVault - amt);
      setPlayerBet({ amount: amt, accepted: false });
    }
  };

  const cashOut = () => {
    if (!canCashOut || phase !== "running") return;
    if (!playerBet?.accepted) return; // only after takeoff
    setCanCashOut(false);
    setCashedOutAt(multiplier);
    cancelAnimationFrame(rafRef.current);

    const winAmount = Math.round(playerBet.amount * multiplier * 100) / 100;
    setPayout({ win: true, amount: winAmount, at: multiplier });

    // Credit to vault
    const newVault = getVault() + winAmount;
    setVault(newVault);
    setVaultState(newVault);
    
    // Update stats
    const newStats = {
      ...stats,
      totalGames: stats.totalGames + 1,
      totalPlay: stats.totalPlay + playerBet.amount,
      wins: stats.wins + 1,
      totalWon: stats.totalWon + winAmount,
      biggestWin: Math.max(stats.biggestWin, winAmount),
      lastPlay: playerBet.amount
    };
    setStats(newStats);
    safeWrite(LS_KEY, newStats);

    setPhase("revealing");
    setTimeout(() => startNextRound(), ROUND.intermissionMs);
  };

  // Auto-hide result popup
  useEffect(() => {
    if (prize) {
      setShowResultPopup(true);
      const timer = setTimeout(() => {
        setShowResultPopup(false);
      }, 4000);
      return () => clearTimeout(timer);
    }
  }, [prize]);

  const resetToSetup = () => {
    setPayout(null);
    setShowResultPopup(false);
    setPhase("playing");
    setCountdown(ROUND.bettingSeconds);
    setMultiplier(1.0);
    setCrashPoint(null);
    setPlayerBet(null);
    setCanCashOut(false);
  };

  // ------------------------------- Derived ----------------------------------
  const chartData = dataRef.current;
  const maxY = useMemo(() => {
    const current = Math.max(1, ...chartData.map((p) => p.m));
    const ceil = Math.ceil(Math.max(current, crashPoint || 1) * 1.1 * 10) / 10;
    return Math.min(ceil, ROUND.maxCrash);
  }, [chartData, crashPoint]);

  // Build SVG path
  const chart = useMemo(() => {
    const W = 600;
    const H = 260;
    const padL = 36, padR = 12, padT = 16, padB = 28;
    const iw = W - padL - padR;
    const ih = H - padT - padB;
    const mMin = 1;
    const mMax = maxY;
    const scaleY = (m) => padT + ih - ((m - mMin) / (mMax - mMin)) * ih;

    if (!chartData.length) {
      return { W, H, d: "", xCrash: null, yCrash: null, padL, padR, padT, padB, scaleY, mMin, mMax };
    }
    
    const tMax = chartData[chartData.length - 1].t || 1000;
    const t0 = chartData[0].t;
    const tSpan = Math.max(1000, tMax - t0); // avoid div/0
    const scaleX = (t) => padL + ((t - t0) / tSpan) * iw;

    let d = "";
    chartData.forEach((p, i) => {
      const x = scaleX(p.t);
      const y = scaleY(p.m);
      d += (i === 0 ? `M ${x} ${y}` : ` L ${x} ${y}`);
    });

    let xCrash = null, yCrash = null;
    if (crashPoint) {
      const lastX = scaleX(chartData[chartData.length - 1].t);
      xCrash = lastX;
      yCrash = scaleY(crashPoint);
    }

    return { W, H, d, xCrash, yCrash, padL, padR, padT, padB, scaleY, mMin, mMax };
  }, [chartData, crashPoint, maxY]);

  // ------------------------------- Render -----------------------------------
  if (!mounted) {
    return <div className="min-h-screen bg-gradient-to-b from-zinc-950 via-zinc-900 to-black text-white flex items-center justify-center">
      <div className="text-xl">Loading...</div>
    </div>;
  }

  return (
    <Layout title="MLEO Sky Run">
      <div className="min-h-screen bg-gradient-to-b from-zinc-950 via-zinc-900 to-black text-white">
        <div className="mx-auto max-w-5xl px-4 py-6 pb-20">
          <header className="flex items-center justify-between mb-6">
            <Link href="/arcade">
              <button className="px-4 py-2 rounded-xl text-sm font-bold bg-white/5 border border-white/10 hover:bg-white/10">
                BACK
              </button>
            </Link>

            <div className="text-center">
              <h1 className="text-3xl font-bold mb-1">
                📈 {isFreePlay && <span className="text-amber-400">🎁 FREE PLAY - </span>}
                Sky Run
              </h1>
              <p className="text-zinc-400 text-sm">
                {isFreePlay ? "Playing with a free token - good luck!" : "Cash out before the crash!"}
              </p>
            </div>

            <div className="w-16"></div>
          </header>

        {/* Playing Panel */}
        <section className="mt-6 grid grid-cols-1 md:grid-cols-3 gap-4">
          <div className="md:col-span-2 rounded-2xl bg-zinc-900/70 p-4 md:p-6 shadow-lg">
            {/* Top row: seeds + multiplier */}
            <div className="flex flex-col md:flex-row md:items-center md:justify-between gap-3">
              <div className="text-xs text-zinc-400">
                <div>
                  <span className="text-zinc-500">serverSeedHash:</span>{" "}
                  <span className="font-mono">{serverSeedHash.slice(0, 16)}…</span>
                </div>
                {phase !== "playing" && (phase === "revealing" || phase === "crashed") ? (
                  <div className="mt-1">
                    <span className="text-zinc-500">serverSeed:</span>{" "}
                    <span className="font-mono break-all">{serverSeed}</span>
                  </div>
                ) : null}
                <div className="mt-1">
                  <span className="text-zinc-500">clientSeed:</span>{" "}
                  <span className="font-mono">{clientSeed}</span>
                  <span className="text-zinc-600"> &nbsp; nonce:</span>{" "}
                  <span className="font-mono">{nonce}</span>
                </div>
              </div>

              <div className="text-right">
                <div className="text-5xl md:text-6xl font-black">
                  <span className={phase === "running" ? "text-emerald-400" : "text-zinc-300"}>
                    {multiplier.toFixed(ROUND.decimals)}×
                  </span>
                </div>
                {crashPoint ? (
                  <div className="text-xs text-zinc-500">Crash at: {crashPoint.toFixed(2)}×</div>
                ) : null}
              </div>
            </div>

            {/* Chart */}
            <div className="mt-4">
              <div className="rounded-xl bg-zinc-950/70 p-2 md:p-3 ring-1 ring-zinc-800">
                <svg
                  viewBox={`0 0 ${chart.W} ${chart.H}`}
                  className="w-full h-64 md:h-72"
                  role="img"
                  aria-label="Crash multiplier chart"
                >
                  {/* axes */}
                  <line x1="36" y1="16" x2="36" y2={chart.H - 28} stroke="#3f3f46" strokeWidth="1" />
                  <line x1="36" y1={chart.H - 28} x2={chart.W - 12} y2={chart.H - 28} stroke="#3f3f46" strokeWidth="1" />

                  {/* y ticks */}
                  {Array.from({ length: 6 }).map((_, i) => {
                    const m = chart.mMin + ((chart.mMax - chart.mMin) * i) / 5;
                    const y = chart.scaleY(m);
                    return (
                      <g key={i}>
                        <line x1="32" y1={y} x2="36" y2={y} stroke="#52525b" />
                        <text x="30" y={y + 4} fontSize="10" textAnchor="end" fill="#a1a1aa">
                          {m.toFixed(1)}×
                        </text>
                      </g>
                    );
                  })}

                  {/* path */}
                  {chart.d ? (
                    <path d={chart.d} fill="none" stroke="#22c55e" strokeWidth="3" strokeLinejoin="round" strokeLinecap="round" />
                  ) : null}

                  {/* crash marker */}
                  {phase !== "playing" && crashPoint && chart.xCrash != null ? (
                    <g>
                      <circle cx={chart.xCrash} cy={chart.yCrash} r="5" fill="#ef4444" />
                      <text x={chart.xCrash + 6} y={chart.yCrash - 6} fontSize="11" fill="#ef4444">
                        {crashPoint.toFixed(2)}×
                      </text>
                    </g>
                  ) : null}
                </svg>
              </div>
            </div>

            {/* Run controls */}
            <div className="mt-4 flex items-center justify-between">
              <div className="text-sm text-zinc-400">
                {phase === "playing" ? (
                  <span>🔒 Plays lock in <span className="text-white font-semibold">{countdown}s</span></span>
                ) : phase === "running" ? (
                  <span>🚀 Round running… click <span className="text-white font-semibold">CASH OUT</span> before it crashes.</span>
                ) : phase === "crashed" ? (
                  <span className="text-red-400">💥 Crashed at {crashPoint?.toFixed(2)}×</span>
                ) : phase === "revealing" ? (
                  <span>🔎 Revealing seeds… Next round shortly.</span>
                ) : (
                  <span>⏳ Next round soon…</span>
                )}
              </div>

              <div>
                <button
                  onClick={cashOut}
                  disabled={!canCashOut || phase !== "running" || !playerBet?.accepted}
                  className={[
                    "rounded-lg px-6 py-2 text-base font-semibold shadow transition",
                    canCashOut && phase === "running" && playerBet?.accepted
                      ? "bg-emerald-500 hover:bg-emerald-400 text-black"
                      : "bg-zinc-800 text-zinc-400 cursor-not-allowed",
                  ].join(" ")}
                >
                  CASH OUT
                </button>
              </div>
            </div>
          </div>

          {/* Play sidebar */}
          <div className="rounded-2xl bg-zinc-900/70 p-4 md:p-5 shadow-lg">
            <h3 className="text-lg font-semibold">Place Your Play</h3>
            <div className="mt-3">
              <label className="block text-sm text-zinc-400 mb-1">Amount (MLEO)</label>
              <input
                type="number"
                min="0"
                step="0.01"
                value={playAmount}
                onChange={(e) => setPlayAmount(e.target.value)}
                className="w-full rounded-lg bg-zinc-950/70 border border-zinc-800 px-3 py-2 text-white focus:outline-none focus:ring-2 focus:ring-emerald-500"
                placeholder="e.g. 100"
                disabled={phase !== "playing"}
              />
              <div className="flex gap-2 mt-2">
                {[100, 250, 500, 1000].map((v) => (
                  <button
                    key={v}
                    onClick={() => setPlayAmount(String(v))}
                    disabled={phase !== "playing"}
                    className="rounded-lg bg-zinc-800 px-3 py-1 text-sm text-zinc-200 hover:bg-zinc-700 disabled:opacity-50"
                  >
                    {v}
                  </button>
                ))}
              </div>
            </div>

            {freePlayTokens > 0 && phase === "playing" && (
              <button
                onClick={() => placeBet(true)}
                className="mt-4 w-full rounded-xl bg-gradient-to-r from-amber-500 via-orange-500 to-yellow-500 px-4 py-2.5 font-semibold text-white shadow hover:from-amber-400 hover:via-orange-400 hover:to-yellow-400"
              >
                🎁 FREE PLAY ({freePlayTokens}/5)
              </button>
            )}
            
            <button
              onClick={() => placeBet(false)}
              disabled={phase !== "playing" || !playAmount || Number(playAmount) <= 0 || Number(playAmount) > vault}
              className="mt-4 w-full rounded-xl bg-emerald-500 px-4 py-2.5 font-semibold text-black shadow hover:bg-emerald-400 disabled:opacity-50 disabled:cursor-not-allowed"
            >
              Join Round
            </button>

            <div className="mt-4 space-y-2 text-sm">
              <div className="flex items-center justify-between">
                <span className="text-zinc-400">Your play</span>
                <span className="font-medium">
                  {playerBet ? `${playerBet.amount} MLEO ${playerBet.accepted ? "(locked)" : "(pending)"}` : "-"}
                </span>
              </div>
              <div className="flex items-center justify-between">
                <span className="text-zinc-400">Potential cashout</span>
                <span className="font-medium">
                  {playerBet?.accepted ? `${(playerBet.amount * multiplier).toFixed(2)} MLEO` : "-"}
                </span>
              </div>
              {prize ? (
                <div className={`mt-2 rounded-lg px-3 py-2 ${prize.win ? "bg-emerald-500/10 text-emerald-300" : "bg-red-500/10 text-red-300"}`}>
                  {prize.win
                    ? `✅ Won ${prize.amount} MLEO at ${prize.at?.toFixed(2)}×`
                    : `❌ Lost — crashed at ${prize.at?.toFixed(2)}×`}
                </div>
              ) : null}
            </div>

            <div className="mt-5 border-t border-zinc-800/80 pt-3 text-xs text-zinc-500 leading-5">
              <p><span className="font-semibold text-zinc-300">Provably-Fair (demo):</span> crash is derived from <code>SHA256(serverSeed|clientSeed|nonce)</code>. You see the server hash before takeoff, and the server seed is revealed after.</p>
            </div>
          </div>
        </section>

        {/* FLOATING RESULT POPUP */}
        {prize && showResultPopup && (
          <div className="fixed inset-0 z-50 flex items-center justify-center pointer-events-none">
            <div 
              className={`text-center p-4 rounded-xl border-2 transition-all duration-500 transform pointer-events-auto max-w-sm mx-4 ${
                showResultPopup ? 'opacity-100 scale-100' : 'opacity-0 scale-50'
              } ${
                prize.win
                  ? "bg-gradient-to-br from-green-600 to-emerald-700 border-green-300 shadow-2xl shadow-green-500/70"
                  : "bg-gradient-to-br from-red-600 to-rose-700 border-red-300 shadow-2xl shadow-red-500/70"
              }`}
            >
              <div className="text-2xl font-black mb-2 animate-pulse text-white drop-shadow-lg">
                {prize.win ? "📈 Cashed Out! 📈" : "💥 Crashed! 💥"}
              </div>
              <div className="text-base mb-2 text-white/90 font-semibold">
                At: ×{prize.at?.toFixed(2)}
              </div>
              {prize.win && (
                <div className="space-y-1">
                  <div className="text-3xl font-black text-white animate-bounce drop-shadow-2xl">
                    +{fmt(prize.amount)} MLEO
                  </div>
                </div>
              )}
              {!prize.win && (
                <div className="text-lg font-bold text-white">
                  Better luck next time!
                </div>
              )}
              <div className="mt-2 text-xs text-white/70 animate-pulse">
                Auto-closing...
              </div>
            </div>
          </div>
        )}
        </div>
      </div>
    </Layout>
  );
}

// ---------------------- Notes for on-chain integration -----------------------
/*
1) Replace local balance and stubs:
   - On play:
       await presaleOrGameContract.placeBet({ value: ..., args: ... })
       // Or approve & transferFrom for ERC20 playing
   - On cash out:
       await gameContract.cashOut(roundId) -> returns prize
   Ensure the multiplier is computed *off-chain server-side* or on-chain VRF,
   and that the client displays the authoritative round state via websockets.

2) Multiplayer / authoritative source:
   - Move seed generation & round state to a server (Node/Socket.IO).
   - Broadcast: phase, countdown, serverSeedHash, multiplier(t), crashPoint.
   - On reveal: broadcast serverSeed and keep an archive for audits.

3) Security:
   - Never let client determine outcomes. This file is a demo; use it as UI.
   - For real money/tokens, rely on server or smart contract as source of truth.

4) Styling:
   - Tailwind assumed. If not, replace classes or add Tailwind to your project.
*/
