import TexasHoldemGame from '../game/mleo-t-holdem';

export default function TexasHoldemPage() {
  return <TexasHoldemGame />;
}
