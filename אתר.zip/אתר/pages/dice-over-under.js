import DiceGame from "../game/mleo-dice";
export default DiceGame;




