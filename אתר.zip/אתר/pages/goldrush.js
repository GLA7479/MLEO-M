import GoldRushGame from "../game/mleo-goldrush";
export default GoldRushGame;




