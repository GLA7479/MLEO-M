import MLEOUltimatePokerPage from "../game/mleo-ultimate-poker";

export default function UltimatePokerPage() {
  return <MLEOUltimatePokerPage />;
}

