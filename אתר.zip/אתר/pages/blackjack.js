import MLEOBlackjackPage from "../game/mleo-blackjack";

export default function BlackjackPage() {
  return <MLEOBlackjackPage />;
}




