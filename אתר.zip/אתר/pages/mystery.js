import MysteryGame from "../game/mleo-mystery";
export default MysteryGame;




