// pages/rush.js
export { default } from "../game/mleo-token-rush";
