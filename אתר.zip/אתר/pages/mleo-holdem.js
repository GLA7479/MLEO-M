import HoldemPage from '../game/mleo-holdem';

export default function MleoHoldemPage() {
  return <HoldemPage />;
}
