import TexasHoldemMultiplayerPage from '../game/mleo-texas-holdem-multiplayer';

export default function TexasHoldemGamePage() {
  return <TexasHoldemMultiplayerPage />;
}


