import CoinFlipGame from '../game/mleo-coin-flip';

export default function CoinFlipPage() {
  return <CoinFlipGame />;
}