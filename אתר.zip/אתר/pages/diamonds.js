import DiamondsGame from "../game/mleo-diamonds";
export default DiamondsGame;




