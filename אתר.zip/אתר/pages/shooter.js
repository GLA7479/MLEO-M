import ShooterGame from "../game/mleo-shooter";
export default ShooterGame;




