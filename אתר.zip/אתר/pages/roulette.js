import RoulettePage from '../game/mleo-roulette';

export default function RouletteGamePage() {
  return <RoulettePage />;
}




