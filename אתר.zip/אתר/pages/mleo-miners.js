// pages/mleo-miners.js
export { default } from "../game/mleo-miners";
