// pages/plinko2.js
export { default } from "../game/mleo-plinko-v1";


