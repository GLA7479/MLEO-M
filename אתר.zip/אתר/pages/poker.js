import PokerPage from '../game/mleo-poker';

export default function PokerGamePage() {
  return <PokerPage />;
}




