import SicBoGame from "../game/mleo-sicbo";
export default SicBoGame;




