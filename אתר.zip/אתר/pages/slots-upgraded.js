import SlotsUpgradedGame from "../game/mleo-slots-upgraded";
export default SlotsUpgradedGame;




