import MegaWheelGame from "../game/mleo-mega-wheel";
export default MegaWheelGame;




