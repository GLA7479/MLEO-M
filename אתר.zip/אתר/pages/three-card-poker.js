import ThreeCardPokerPage from '../game/mleo-three-card-poker';

export default function ThreeCardPokerGamePage() {
  return <ThreeCardPokerPage />;
}




