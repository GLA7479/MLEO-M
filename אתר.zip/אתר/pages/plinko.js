// pages/plinko.js
export { default } from "../game/mleo-plinko-v2";


