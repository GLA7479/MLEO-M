// pages/hilo.js
export { default } from "../game/mleo-hilo";


