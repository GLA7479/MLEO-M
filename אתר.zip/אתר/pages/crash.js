// pages/crash.js
export { default } from "../game/mleo-crash-v2";


