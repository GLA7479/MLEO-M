import DragonTowerGame from "../game/mleo-dragon-tower";
export default DragonTowerGame;




