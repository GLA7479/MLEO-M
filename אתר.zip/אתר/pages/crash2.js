// pages/crash2.js
export { default } from "../game/mleo-crash-v1";


