import LadderGame from "../game/mleo-ladder";
export default LadderGame;




